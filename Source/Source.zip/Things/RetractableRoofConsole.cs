using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

using SolarWeb.Stratum.DefModExtensions;
using SolarWeb.Stratum.MapComponents;
using SolarWeb.Stratum.Stats;

namespace SolarWeb.Stratum.Things;

public class RetractableRoofConsole : Building
{
  public bool isOpeningRequested;
  public bool isTransitioning;
  public bool jobPending;
  public int currentRingIndex;
  public float transitionProgress;

  private List<List<IntVec3>> transitionRings = [];
  private HashSet<IntVec3> canopyCells = [];
  private Vector3 roomCentroid;
  private CompPowerTrader? powerComp;
  private RetractableRoofTracker? cachedTracker;
  private RoofIntegrityGrid? cachedIntegrityGrid;
  private RetractableRoofAnimator? cachedAnimator;
  private readonly HashSet<IntVec3> simulatedRetracted = [];
  private readonly HashSet<IntVec3> cellsToCheck = [];
  private readonly Queue<IntVec3> supportCheckQueue = new();
  private readonly HashSet<IntVec3> supportCheckVisited = [];

  public override void SpawnSetup(Map map, bool respawningAfterLoad)
  {
    base.SpawnSetup(map, respawningAfterLoad);
    powerComp = GetComp<CompPowerTrader>();
    cachedTracker = map.GetComponent<RetractableRoofTracker>();
    cachedIntegrityGrid = map.GetComponent<RoofIntegrityGrid>();
    cachedAnimator = map.GetComponent<RetractableRoofAnimator>();

    if (respawningAfterLoad && isTransitioning)
    {
      RecalculateRings();
    }
  }

  public override void DeSpawn(DestroyMode mode = DestroyMode.Vanish)
  {
    base.DeSpawn(mode);
    cachedTracker = null;
    cachedIntegrityGrid = null;
    cachedAnimator = null;
  }

  public override void ExposeData()
  {
    base.ExposeData();
    Scribe_Values.Look(ref isOpeningRequested, "isOpeningRequested", false);
    Scribe_Values.Look(ref isTransitioning, "isTransitioning", false);
    Scribe_Values.Look(ref jobPending, "jobPending", false);
    Scribe_Values.Look(ref currentRingIndex, "currentRingIndex", 0);
    Scribe_Values.Look(ref transitionProgress, "transitionProgress", 0f);
  }

  public override IEnumerable<Gizmo> GetGizmos()
  {
    foreach (var g in base.GetGizmos()) yield return g;

    if (powerComp != null && powerComp.PowerOn)
    {
      if (!isTransitioning)
      {
        bool targetState = !isOpeningRequested;
        yield return new Command_Action
        {
          defaultLabel = targetState ? "Stratum_OpenCanopy".Translate() : "Stratum_CloseCanopy".Translate(),
          defaultDesc = targetState ? "Stratum_OpenCanopyDesc".Translate() : "Stratum_CloseCanopyDesc".Translate(),
          icon = targetState ? TexCommand.Install : TexCommand.ForbidOff,
          action = () =>
          {
            isOpeningRequested = targetState;
            jobPending = true;
          }
        };
      }
      else
      {
        yield return new Command_Action
        {
          defaultLabel = "Stratum_CancelTransition".Translate(),
          defaultDesc = "Stratum_CancelTransitionDesc".Translate(),
          icon = TexCommand.ClearPrioritizedWork,
          action = () =>
          {
            isTransitioning = false;
            jobPending = false;
          }
        };
      }
    }
  }

  public float GetActivePowerDraw()
  {
    return Mathf.Max(500f, 50f * canopyCells.Count);
  }

  public override string GetInspectString()
  {
    if (Map == null || Map.roofGrid == null) return base.GetInspectString();
    string str = base.GetInspectString();

    if (canopyCells.Count == 0 && this.IsHashIntervalTick(60))
    {
      RecalculateRings();
    }

    string statusKey = "Stratum_CanopyIdle";
    if (isTransitioning)
    {
      statusKey = isOpeningRequested ? "Stratum_CanopyOpening" : "Stratum_CanopyClosing";
    }
    else if (canopyCells.Count > 0)
    {
      int openCount = 0;
      foreach (var c in canopyCells)
      {
        if (Map.roofGrid.RoofAt(c) == null) openCount++;
      }
      if (openCount == canopyCells.Count) statusKey = "Stratum_CanopyRetracted";
      else if (openCount == 0) statusKey = "Stratum_CanopyExtended";
      else statusKey = "Stratum_CanopyPartiallyRetracted";
    }

    if (!str.NullOrEmpty()) str += "\n";
    str += "Stratum_CanopyStatus".Translate(statusKey.Translate()) + "\n";
    str += "Stratum_ConnectedTiles".Translate(canopyCells.Count) + "\n";
    str += "Stratum_TransitionPower".Translate(GetActivePowerDraw());

    return str;
  }

  public override void DrawExtraSelectionOverlays()
  {
    base.DrawExtraSelectionOverlays();

    if (canopyCells.Count > 0)
    {
      GenDraw.DrawFieldEdges(canopyCells.ToList(), Color.cyan, null);
    }
  }

  public void InitiateTransition()
  {
    if (Map == null) return;
    RecalculateRings();
    isTransitioning = true;
    jobPending = false;
    transitionProgress = 9999f; // Trigger first ring immediately on next tick

    if (isOpeningRequested)
    {
      currentRingIndex = 0;
      while (currentRingIndex < transitionRings.Count && RingIsAlreadyOpen(transitionRings[currentRingIndex]))
        currentRingIndex++;
    }
    else
    {
      currentRingIndex = transitionRings.Count - 1;
      while (currentRingIndex >= 0 && RingIsAlreadyClosed(transitionRings[currentRingIndex]))
        currentRingIndex--;
    }
  }

  private bool IsRetractableRoof(RoofDef roof)
  {
    return roof != null && roof.GetModExtension<BuildableRoofExtension>()?.isRetractable == true;
  }

  private bool RingIsAlreadyOpen(List<IntVec3> ring)
  {
    if (Map == null || Map.roofGrid == null) return true;
    foreach (var cell in ring)
    {
      var roof = Map.roofGrid.RoofAt(cell);
      if (IsRetractableRoof(roof))
        return false;
    }
    return true;
  }

  private bool RingIsAlreadyClosed(List<IntVec3> ring)
  {
    if (Map == null || Map.roofGrid == null) return true;
    foreach (var cell in ring)
    {
      var roof = Map.roofGrid.RoofAt(cell);
      if (!IsRetractableRoof(roof))
        return false;
    }
    return true;
  }

  private void RecalculateRings()
  {
    var tracker = cachedTracker;
    HashSet<IntVec3> validCells;

    var room = this.GetRoom();
    if (room == null)
    {
      transitionRings.Clear();
      return;
    }

    var roomValidCells = new HashSet<IntVec3>();
    foreach (var cell in room.Cells)
    {
      int idx = Map.cellIndices.CellToIndex(cell);
      var r = Map.roofGrid.RoofAt(cell);

      bool isValid = false;
      if (IsRetractableRoof(r)) isValid = true;
      else if (tracker != null && tracker.IsRetracted(idx)) isValid = true;

      if (isValid)
      {
        roomValidCells.Add(cell);
      }
    }

    if (roomValidCells.Count == 0)
    {
      transitionRings.Clear();
      return;
    }

    if (!room.TouchesMapEdge)
    {
      validCells = roomValidCells;
    }
    else
    {
      var unvisited = new HashSet<IntVec3>(roomValidCells);
      var components = new List<HashSet<IntVec3>>();

      while (unvisited.Count > 0)
      {
        var comp = new HashSet<IntVec3>();
        var queue = new Queue<IntVec3>();

        var start = unvisited.First();
        queue.Enqueue(start);
        unvisited.Remove(start);
        comp.Add(start);

        while (queue.Count > 0)
        {
          var curr = queue.Dequeue();
          for (int i = 0; i < 8; i++)
          {
            IntVec3 n = curr + GenAdj.AdjacentCells[i];
            if (unvisited.Contains(n))
            {
              unvisited.Remove(n);
              comp.Add(n);
              queue.Enqueue(n);
            }
          }
        }
        components.Add(comp);
      }

      HashSet<IntVec3> closestComp = components[0];
      float minDist = float.MaxValue;

      Vector3 consolePos = Position.ToVector3Shifted();
      foreach (var comp in components)
      {
        float dist = float.MaxValue;
        foreach (var c in comp)
        {
          float d = Vector3.Distance(c.ToVector3Shifted(), consolePos);
          if (d < dist) dist = d;
        }
        if (dist < minDist)
        {
          minDist = dist;
          closestComp = comp;
        }
      }

      validCells = closestComp;
    }

    float sumX = 0;
    float sumZ = 0;
    foreach (var c in validCells)
    {
      sumX += c.x;
      sumZ += c.z;
    }
    roomCentroid = new Vector3(sumX / validCells.Count, 0f, sumZ / validCells.Count);
    Vector3 centroid = roomCentroid;

    var dict = new SortedDictionary<float, List<IntVec3>>();
    foreach (var c in validCells)
    {
      float dist = Vector3.Distance(c.ToVector3Shifted(), centroid);
      float roundedDist = Mathf.Round(dist * 2f) / 2f;
      if (!dict.TryGetValue(roundedDist, out var list))
      {
        list = [];
        dict[roundedDist] = list;
      }
      list.Add(c);
    }

    transitionRings = dict.Values.ToList();
    canopyCells = validCells;
  }

  protected override void Tick()
  {
    base.Tick();
    if (Map == null || !Spawned || Map.roofGrid == null) return;

    try
    {
      if (!isTransitioning)
      {
        if (Find.Selector.IsSelected(this) && this.IsHashIntervalTick(60))
        {
          RecalculateRings();
        }

        if (powerComp != null)
        {
          powerComp.PowerOutput = -200f;
        }
        return;
      }

      if (powerComp != null && !powerComp.PowerOn)
      {
        var flick = GetComp<CompFlickable>();
        if (flick != null && !flick.SwitchIsOn) return;

        var breakdown = GetComp<CompBreakdownable>();
        if (breakdown != null && breakdown.BrokenDown) return;
      }

      float desiredPower = GetActivePowerDraw();

      if (powerComp != null)
      {
        powerComp.PowerOutput = -desiredPower;
      }

      if (transitionRings.Count == 0 ||
         (isOpeningRequested && currentRingIndex >= transitionRings.Count) ||
         (!isOpeningRequested && currentRingIndex < 0))
      {
        isTransitioning = false;
        return;
      }

    int animationDuration = 1; // Default minimum to prevent div by 0
    var tracker = cachedTracker;
    var currentRing = transitionRings[currentRingIndex];
    foreach (var cell in currentRing)
    {
      var rDef = Map.roofGrid.RoofAt(cell);

        if (rDef == null && tracker != null)
        {
          int index = Map.cellIndices.CellToIndex(cell);
          tracker.PeekOpenRoof(index, out rDef, out _, out _, out _);
        }

        if (rDef != null)
        {
          var ext = rDef.GetModExtension<BuildableRoofExtension>();
          if (ext != null && ext.isRetractable)
          {
            int ticks = 30;
            if (ext.buildableDef != null)
            {
              ticks = Mathf.RoundToInt(ext.buildableDef.GetStatValueAbstract(DefOf.StatDefOf.TransitionSpeed));
            }

            if (ticks > animationDuration)
            {
              animationDuration = ticks;
            }
          }
        }
      }

    int delayTicks = Mathf.Max(1, animationDuration / 3);
    int ticksToNextRing = animationDuration + delayTicks;

      float speedMultiplier = 1f;
      transitionProgress += speedMultiplier;

      if (transitionProgress >= ticksToNextRing)
      {
        transitionProgress = 0f;

      var ring = transitionRings[currentRingIndex];
      var integrityGrid = cachedIntegrityGrid;

        foreach (var cell in ring)
        {
          int index = Map.cellIndices.CellToIndex(cell);

          if (isOpeningRequested)
          {
            var roof = Map.roofGrid.RoofAt(cell);
            if (IsRetractableRoof(roof))
            {
              bool bordersEmptyAir = false;
              for (int i = 0; i < 8; i++)
              {
                IntVec3 n = cell + GenAdj.AdjacentCells[i];
                if (!n.InBounds(Map)) continue;

                if (!canopyCells.Contains(n))
                {
                  bool hasRoof = Map.roofGrid.RoofAt(n) != null;
                  bool hasEdifice = n.GetEdifice(Map) != null;
                  if (!hasRoof && !hasEdifice)
                  {
                    bordersEmptyAir = true;
                    break;
                  }
                }
              }

              if (bordersEmptyAir)
              {
                continue;
              }

              // Check if retracting this cell would leave any other roof tile unsupported
              bool wouldCauseCollapse = false;
              simulatedRetracted.Clear();
              simulatedRetracted.Add(cell);
 
              cellsToCheck.Clear();
              foreach (var c in canopyCells)
              {
                if (Map.roofGrid.RoofAt(c) != null && c != cell)
                {
                  cellsToCheck.Add(c);
                }
                for (int i = 0; i < 8; i++)
                {
                  IntVec3 adj = c + GenAdj.AdjacentCells[i];
                  if (adj.InBounds(Map) && !canopyCells.Contains(adj) && Map.roofGrid.RoofAt(adj) != null)
                  {
                    cellsToCheck.Add(adj);
                  }
                }
              }
 
              foreach (var c in cellsToCheck)
              {
                if (IsCellSupported(c) && !IsCellSupported(c, simulatedRetracted))
                {
                  wouldCauseCollapse = true;
                  break;
                }
              }

              if (wouldCauseCollapse)
              {
                continue;
              }

              var stuff = integrityGrid?.GetStuff(cell);
              var tint = integrityGrid?.GetGlassTint(cell);
              var hp = integrityGrid?.GetHitPoints(cell) ?? (short)180;

              tracker?.SaveOpenRoof(index, roof, stuff, tint, hp);

              var gd = RoofStatCache.GetGraphicData(roof);
              if (gd != null)
              {
                var entry = Graphics.RoofAtlasManager.GetEntry(gd.texPath);
                Vector2[]? uvs = null;

                if (entry.IsSeamless && entry.SeamlessGrid != null)
                {
                  int col = cell.x % entry.GridWidth;
                  if (col < 0) col += entry.GridWidth;
                  int row = cell.z % entry.GridHeight;
                  if (row < 0) row += entry.GridHeight;

                  if (entry.SeamlessGrid.TryGetValue((col, row), out var uvEntry))
                  {
                    uvs = uvEntry;
                  }
                }
                else if (entry.FlatVariants.Count > 0)
                {
                  uvs = entry.FlatVariants[Mathf.Abs(cell.GetHashCode()) % entry.FlatVariants.Count];
                }

                if (uvs != null)
                {
                  var animator = Map.GetComponent<RetractableRoofAnimator>();
                  if (animator != null)
                  {
                    Vector3 start = cell.ToVector3Shifted();
                    Vector3 rawDir = (start - roomCentroid).normalized;
                    Vector3 dir = Mathf.Abs(rawDir.x) > Mathf.Abs(rawDir.z)
                      ? new Vector3(Mathf.Sign(rawDir.x), 0, 0)
                      : new Vector3(0, 0, Mathf.Sign(rawDir.z));
                    Vector3 end = start + dir * 1f;

                    Color color = RoofStatCache.GetColor(roof, stuff);
                    if (RoofStatCache.IsSkylight(roof))
                    {
                      color.a = 1f - RoofStatCache.GetTransparency(roof);
                    }
                    
                    var mats = Graphics.RoofAtlasManager.GetTransitionMaterials(gd.texPath, color);
                    Material mat = roof.isNatural
                      ? Graphics.RoofAtlasManager.GetMetaOverlay(gd.texPath)
                      : (RoofStatCache.IsSkylight(roof) ? mats.transparent : mats.cutout);
                    
                    Color vertexColor = roof.isNatural ? color : Color.white;
                    animator.AddTransition(start, end, animationDuration, mat, vertexColor, uvs);
                  }
                }
              }

              Map.roofGrid.SetRoof(cell, null);
              FleckMaker.ThrowAirPuffUp(cell.ToVector3Shifted(), Map);
            }
          }
          else
          {
            if (tracker != null && tracker.PopOpenRoof(index, out var rDef, out var stuff, out var tint, out var hp))
            {
              if (Map.roofGrid.RoofAt(cell) == null)
              {
                var gd = RoofStatCache.GetGraphicData(rDef);
                var animator = Map.GetComponent<RetractableRoofAnimator>();
                if (gd != null)
                {
                  var entry = Graphics.RoofAtlasManager.GetEntry(gd.texPath);
                  Vector2[]? uvs = null;

                  if (entry.IsSeamless && entry.SeamlessGrid != null)
                  {
                    int col = cell.x % entry.GridWidth;
                    if (col < 0) col += entry.GridWidth;
                    int row = cell.z % entry.GridHeight;
                    if (row < 0) row += entry.GridHeight;

                    if (entry.SeamlessGrid.TryGetValue((col, row), out var uvEntry))
                    {
                      uvs = uvEntry;
                    }
                  }
                  else if (entry.FlatVariants.Count > 0)
                  {
                    uvs = entry.FlatVariants[Mathf.Abs(cell.GetHashCode()) % entry.FlatVariants.Count];
                  }

                  if (uvs != null)
                  {
                    if (animator != null)
                    {
                      Vector3 end = cell.ToVector3Shifted();
                      Vector3 rawDir = (end - roomCentroid).normalized;
                      Vector3 dir = Mathf.Abs(rawDir.x) > Mathf.Abs(rawDir.z)
                        ? new Vector3(Mathf.Sign(rawDir.x), 0, 0)
                        : new Vector3(0, 0, Mathf.Sign(rawDir.z));
                      Vector3 start = end + dir * 1f;

                      Color color = RoofStatCache.GetColor(rDef, stuff);
                      if (RoofStatCache.IsSkylight(rDef))
                      {
                        color.a = 1f - RoofStatCache.GetTransparency(rDef);
                      }
                      
                      var mats = Graphics.RoofAtlasManager.GetTransitionMaterials(gd.texPath, color);
                      Material mat = rDef.isNatural
                        ? Graphics.RoofAtlasManager.GetMetaOverlay(gd.texPath)
                        : (RoofStatCache.IsSkylight(rDef) ? mats.transparent : mats.cutout);
                      
                      Color vertexColor = rDef.isNatural ? color : Color.white;
                      animator.AddTransition(start, end, animationDuration, mat, vertexColor, uvs);
                    }
                  }
                }

                if (animator != null)
                {
                  animator.AddPendingRoof(cell, rDef, stuff, tint ?? Color.white, hp, animationDuration);
                }
                else
                {
                  Map.roofGrid.SetRoof(cell, rDef);
                  integrityGrid?.InitializeRoof(cell, rDef, stuff, tint, hp);
                  FleckMaker.ThrowAirPuffUp(cell.ToVector3Shifted(), Map);
                }
              }
            }
          }
        }

        DefOf.SoundDefOf.DropPod_Open?.PlayOneShot(new TargetInfo(Position, Map));

        if (isOpeningRequested)
          currentRingIndex++;
        else
          currentRingIndex--;
      }
    }
    catch (System.Exception ex)
    {
      StratumLog.Error($"Error in RetractableRoofConsole.Tick: {ex}");
      isTransitioning = false;
    }
  }

  private bool IsRoofHolder(IntVec3 c)
  {
    if (Map == null) return false;
    Building edifice = c.GetEdifice(Map);
    return edifice != null && edifice.def != null && edifice.def.holdsRoof;
  }

  private bool IsCellSupported(IntVec3 startCell, HashSet<IntVec3>? simulatedRetracted = null)
  {
    if (Map?.roofGrid == null) return false;
    if (IsRoofHolder(startCell)) return true;

    supportCheckQueue.Clear();
    supportCheckVisited.Clear();

    supportCheckQueue.Enqueue(startCell);
    supportCheckVisited.Add(startCell);

    while (supportCheckQueue.Count > 0)
    {
      IntVec3 curr = supportCheckQueue.Dequeue();

      if (IsRoofHolder(curr))
      {
        if (ChebyshevDistance(startCell, curr) <= 6)
        {
          return true;
        }
      }

      for (int i = 0; i < 4; i++)
      {
        IntVec3 n = curr + GenAdj.CardinalDirections[i];
        if (!n.InBounds(Map)) continue;

        if (IsRoofHolder(n))
        {
          if (ChebyshevDistance(startCell, n) <= 6)
          {
            return true;
          }
        }

        if (!supportCheckVisited.Contains(n))
        {
          var roof = Map.roofGrid.RoofAt(n);
          if (roof != null && (simulatedRetracted == null || !simulatedRetracted.Contains(n)))
          {
            supportCheckVisited.Add(n);
            supportCheckQueue.Enqueue(n);
          }
        }
      }
    }

    return false;
  }

  private static int ChebyshevDistance(IntVec3 a, IntVec3 b)
  {
    return Mathf.Max(Mathf.Abs(a.x - b.x), Mathf.Abs(a.z - b.z));
  }
}
